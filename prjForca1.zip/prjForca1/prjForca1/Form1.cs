﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjForca1
{
    public partial class Form1 : Form
    {


        Forca jogo;
        Label[] letras;
        string letrasDigitadas =  "";
        int erros = 0;

        string[] lista;
        string[] dicas;

        SoundPlayer som;
        

        public Form1()
        {
            InitializeComponent();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PreencherLista();

            jogo = new Forca(lista, dicas, 0); // cria o jogo
            jogo.SortearPalavra(); // sorteia palavra
            string p= jogo.devolvePalavra(); // mostra a palavra
            desenhaPalavra(p);
            temporizador.Enabled = true;
            string caminho = Environment.CurrentDirectory + "\\fundosom.wav";

            som = new SoundPlayer();
            som.SoundLocation = caminho;
            som.PlayLooping();
            lbDica.Text = "DICA DA PALAVRA: " +jogo.devolveDica();
        }

        private void PreencherLista()
        {
            string caminho = Environment.CurrentDirectory + "\\lista.txt";
            StreamReader arquivo = new StreamReader(caminho);
            int qtd = File.ReadAllLines(caminho).Count();

            lista = new string[qtd];
            dicas = new string[qtd];

            for (int i = 0; i < qtd; i++)
            {
                string[] palavra = arquivo.ReadLine().Split(',');
                lista[i] = palavra[0];
                dicas[i] = palavra[1];
            }
        }

        private void desenhaPalavra(string p)
        {
            letras = new Label[p.Length];
            int pv = 40, ph = 40;

            for (int i = 0; i < letras.Count(); i++)
            {
                letras[i] = new Label();
                letras[i].Text = "?";
                letras[i].BackColor = Color.White;
                letras[i].ForeColor = Color.Aquamarine;
                letras[i].AutoSize = false;
                letras[i].Width = 40;
                letras[i].Height = 40;
                letras[i].BorderStyle = BorderStyle.Fixed3D;
                letras[i].TextAlign = ContentAlignment.MiddleCenter;
                
                if (i % 5 == 0 & i !=0)
                {
                    pv = pv + 45;
                    ph = 40;
                }

                letras[i].Top = pv;
                letras[i].Left = ph;
                pnPalavraSecreta.Controls.Add(letras[i]);
                letras[i].Show();
                ph += 45;
            }
            }

        private void btnJogar_Click(object sender, EventArgs e)
        {
            desenharLetras(txtLetra.Text);
            txtLetra.Clear();
            txtLetra.Focus();
        }

        private void desenharLetras(string letra)
        {
            string p = jogo.devolvePalavra();
            bool achou = false;

            if (!letrasDigitadas.Contains(letra) && !letra.Equals(""))
            {
                letrasDigitadas += letra;
                lblLetrasDigitadas.Text = letrasDigitadas;
            }
            else
            {
                if (!letra.Equals(""))
                {


                    MessageBox.Show("Letra já digitada!");
                    return;

                }
            }


            

            for (int i = 0; i < p.Length; i++)
            {
                if (p.Substring(i,1).Equals(letra))
                {
                    letras[i].Text = letra;
                    achou = true;
                }
            }

            if (achou == false)
            {
                erros++;
                desenharEnforcado();
            }
            if (erros == 6)
            {
                temporizador.Enabled = false;
                MessageBox.Show("Você perdeu!!! A palavra era: " + p);
                temporizador.Enabled = true;
                NovoJogo();
            }

            TestarVitoria();
        }

        private void TestarVitoria()
        {
            string p = jogo.devolvePalavra();
            string tmp = "";

            for (int i = 0; i < letras.Count(); i++)
            {
                tmp += letras[i].Text;
            }

            if (p.Equals(tmp))
            {
                temporizador.Enabled = false;
                MessageBox.Show("Parabéns! Você venceu!!!");
                temporizador.Enabled = true;
                NovoJogo();
            }
        }

        private void NovoJogo()
        {
            pnPalavraSecreta.Controls.Clear();
            jogo.SortearPalavra();
            erros = 0;
            desenhaPalavra(jogo.devolvePalavra());
            pbEnforcado.Image = null;
            lblLetrasDigitadas.Text = "";
            letrasDigitadas = "";
            lbCronometro.Text = "60";
            lbDica.Text = "DICA DA PALAVRA: " +jogo.devolveDica();
        }

        private void desenharEnforcado()
        {
            try
            {
                string pasta = Environment.CurrentDirectory + "\\imagens\\";
                string arquivo = pasta + "forca" + erros.ToString() + ".png";
                pbEnforcado.Image = Image.FromFile(arquivo);
            }
            catch (Exception erro)
            {
                
                MessageBox.Show("Arquivo de imagens não existe!:" + erro.Message);
                    this.Dispose();
            }
            
        }

        private void txtLetra_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnJogar_Click(sender, e);
            }
        }

        private void temporizador_Tick(object sender, EventArgs e)
        {
            int segundo = Convert.ToInt16(lbCronometro.Text);
            segundo--;
            lbCronometro.Text = segundo.ToString();
            Console.Beep();

            if (segundo == 0)
            {
                temporizador.Enabled = false;
                MessageBox.Show("Tempo esgotado! A palavra era: " + jogo.devolvePalavra());
                temporizador.Enabled = true;
               NovoJogo();
            }
        }

        private void btNovoJogo_Click(object sender, EventArgs e)
        {
            NovoJogo();
        }

     
            }
            }
        
    

