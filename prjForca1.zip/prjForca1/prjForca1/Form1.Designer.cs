﻿namespace prjForca1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pnLetra = new System.Windows.Forms.Panel();
            this.btnJogar = new System.Windows.Forms.Button();
            this.txtLetra = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pnPalavraSecreta = new System.Windows.Forms.Panel();
            this.lbDica = new System.Windows.Forms.Label();
            this.lblLetrasDigitadas = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pbEnforcado = new System.Windows.Forms.PictureBox();
            this.lbCronometro = new System.Windows.Forms.Label();
            this.temporizador = new System.Windows.Forms.Timer(this.components);
            this.btNovoJogo = new System.Windows.Forms.Button();
            this.pnLetra.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEnforcado)).BeginInit();
            this.SuspendLayout();
            // 
            // pnLetra
            // 
            this.pnLetra.BackColor = System.Drawing.Color.Transparent;
            this.pnLetra.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnLetra.Controls.Add(this.btnJogar);
            this.pnLetra.Controls.Add(this.txtLetra);
            this.pnLetra.Controls.Add(this.label1);
            this.pnLetra.Location = new System.Drawing.Point(12, 12);
            this.pnLetra.Name = "pnLetra";
            this.pnLetra.Size = new System.Drawing.Size(200, 148);
            this.pnLetra.TabIndex = 0;
            // 
            // btnJogar
            // 
            this.btnJogar.BackColor = System.Drawing.Color.White;
            this.btnJogar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnJogar.Location = new System.Drawing.Point(3, 95);
            this.btnJogar.Name = "btnJogar";
            this.btnJogar.Size = new System.Drawing.Size(192, 48);
            this.btnJogar.TabIndex = 2;
            this.btnJogar.Tag = "";
            this.btnJogar.Text = "JOGAR";
            this.btnJogar.UseVisualStyleBackColor = false;
            this.btnJogar.Click += new System.EventHandler(this.btnJogar_Click);
            // 
            // txtLetra
            // 
            this.txtLetra.BackColor = System.Drawing.Color.White;
            this.txtLetra.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtLetra.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLetra.Location = new System.Drawing.Point(3, 29);
            this.txtLetra.MaxLength = 1;
            this.txtLetra.Name = "txtLetra";
            this.txtLetra.Size = new System.Drawing.Size(192, 43);
            this.txtLetra.TabIndex = 1;
            this.txtLetra.Text = "A";
            this.txtLetra.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtLetra.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtLetra_KeyUp);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.RoyalBlue;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(198, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "DIGITE UMA LETRA";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnPalavraSecreta
            // 
            this.pnPalavraSecreta.BackColor = System.Drawing.Color.Transparent;
            this.pnPalavraSecreta.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnPalavraSecreta.Location = new System.Drawing.Point(230, 42);
            this.pnPalavraSecreta.Name = "pnPalavraSecreta";
            this.pnPalavraSecreta.Size = new System.Drawing.Size(491, 118);
            this.pnPalavraSecreta.TabIndex = 1;
            // 
            // lbDica
            // 
            this.lbDica.BackColor = System.Drawing.Color.RoyalBlue;
            this.lbDica.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbDica.ForeColor = System.Drawing.Color.White;
            this.lbDica.Location = new System.Drawing.Point(227, 12);
            this.lbDica.Name = "lbDica";
            this.lbDica.Size = new System.Drawing.Size(493, 26);
            this.lbDica.TabIndex = 1;
            this.lbDica.Text = "DICA DA PALAVRA";
            this.lbDica.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblLetrasDigitadas
            // 
            this.lblLetrasDigitadas.BackColor = System.Drawing.Color.Transparent;
            this.lblLetrasDigitadas.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLetrasDigitadas.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLetrasDigitadas.ForeColor = System.Drawing.Color.White;
            this.lblLetrasDigitadas.Location = new System.Drawing.Point(12, 163);
            this.lblLetrasDigitadas.Name = "lblLetrasDigitadas";
            this.lblLetrasDigitadas.Padding = new System.Windows.Forms.Padding(5);
            this.lblLetrasDigitadas.Size = new System.Drawing.Size(708, 38);
            this.lblLetrasDigitadas.TabIndex = 2;
            this.lblLetrasDigitadas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 220);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(252, 426);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // pbEnforcado
            // 
            this.pbEnforcado.BackColor = System.Drawing.Color.Transparent;
            this.pbEnforcado.Location = new System.Drawing.Point(67, 288);
            this.pbEnforcado.Name = "pbEnforcado";
            this.pbEnforcado.Size = new System.Drawing.Size(197, 336);
            this.pbEnforcado.TabIndex = 4;
            this.pbEnforcado.TabStop = false;
            // 
            // lbCronometro
            // 
            this.lbCronometro.BackColor = System.Drawing.Color.Transparent;
            this.lbCronometro.Font = new System.Drawing.Font("Segoe UI", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCronometro.ForeColor = System.Drawing.Color.SlateGray;
            this.lbCronometro.Image = ((System.Drawing.Image)(resources.GetObject("lbCronometro.Image")));
            this.lbCronometro.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lbCronometro.Location = new System.Drawing.Point(562, 484);
            this.lbCronometro.Name = "lbCronometro";
            this.lbCronometro.Size = new System.Drawing.Size(159, 137);
            this.lbCronometro.TabIndex = 5;
            this.lbCronometro.Text = "60";
            this.lbCronometro.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // temporizador
            // 
            this.temporizador.Interval = 1000;
            this.temporizador.Tick += new System.EventHandler(this.temporizador_Tick);
            // 
            // btNovoJogo
            // 
            this.btNovoJogo.BackColor = System.Drawing.Color.Transparent;
            this.btNovoJogo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btNovoJogo.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btNovoJogo.Location = new System.Drawing.Point(284, 541);
            this.btNovoJogo.Name = "btNovoJogo";
            this.btNovoJogo.Size = new System.Drawing.Size(83, 80);
            this.btNovoJogo.TabIndex = 6;
            this.btNovoJogo.Text = "NOVO JOGO";
            this.btNovoJogo.UseVisualStyleBackColor = false;
            this.btNovoJogo.Click += new System.EventHandler(this.btNovoJogo_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(733, 675);
            this.Controls.Add(this.lbDica);
            this.Controls.Add(this.btNovoJogo);
            this.Controls.Add(this.lbCronometro);
            this.Controls.Add(this.pbEnforcado);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblLetrasDigitadas);
            this.Controls.Add(this.pnPalavraSecreta);
            this.Controls.Add(this.pnLetra);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "JOGO DA FORCA";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.CursorChanged += new System.EventHandler(this.btNovoJogo_Click);
            this.pnLetra.ResumeLayout(false);
            this.pnLetra.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEnforcado)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnLetra;
        private System.Windows.Forms.TextBox txtLetra;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnPalavraSecreta;
        private System.Windows.Forms.Label lbDica;
        private System.Windows.Forms.Button btnJogar;
        private System.Windows.Forms.Label lblLetrasDigitadas;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pbEnforcado;
        private System.Windows.Forms.Label lbCronometro;
        private System.Windows.Forms.Timer temporizador;
        private System.Windows.Forms.Button btNovoJogo;
    }
}

