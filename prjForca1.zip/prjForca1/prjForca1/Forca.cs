﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjForca1
{
    class Forca
    {
        private string[] palavra;
        private string[] dicas;
        
        private int pos;

        public Forca(string[] palavra, string[] dicas, int pos)
        {

            this.palavra = palavra;
            this.dicas = dicas;
            this.pos = pos;
        }

        public void SortearPalavra()
        {
            Random sorteio = new Random(); // faz o sorteio
            this.pos = sorteio.Next(0, palavra.Count());
        }

        public string devolvePalavra()
        {
            return palavra[pos];
        }
        public string devolveDica()
        {
            return dicas[pos];
        }
    }
}
